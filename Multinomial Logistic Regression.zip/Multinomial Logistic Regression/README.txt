This project develops a logistic regression for multi-class classification. 
We provide the optimization algorithm and mathematical formulation used..

Useful resources:

-Ng, A. Y. and Jordan, M. I. (2002). On discriminative vs. generative classifiers: 
	A comparison of logistic regression and naive bayes. In NIPS 14, 841–848.
-Bishop, C. M. (2006). Pattern recognition and machine learning. Springer